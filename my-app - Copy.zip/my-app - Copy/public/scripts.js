// Function to add material to the table
async function addMaterial() {
    const material = document.getElementById('material').value;
    const day = document.getElementById('day').value;
    const time = document.getElementById('time').value;
    const classroom = document.getElementById('classroom').value;

    if (material && day && time && classroom) {
        const newCourse = {
            name: material,
            section: classroom,
            startTime: time,
            endTime: time,
            days: [day]
        };

        try {
            const response = await fetch('http://localhost:3000/api/courses', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newCourse)
            });

            if (response.ok) {
                const savedCourse = await response.json();
                addMaterialToTable(savedCourse);
                document.getElementById('schedule-form').reset();
            } else {
                alert('Failed to add material');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while adding material');
        }
    } else {
        alert('Please fill out all fields.');
    }
}

function addMaterialToTable(course) {
    const tableBody = document.getElementById('schedule-body');
    const row = document.createElement('tr');
    row.dataset.id = course._id;

    row.innerHTML = `
        <td>${course.days[0]}</td>
        <td>${course.startTime}</td>
        <td>${course.name}</td>
        <td>${course.section}</td>
        <td><button class="btn" onclick="removeRow(this)">Remove</button></td>
    `;

    tableBody.appendChild(row);
}

// Function to fetch and display courses from the server
async function fetchCourses() {
    try {
        const response = await fetch('http://localhost:3000/api/courses');
        const courses = await response.json();

        courses.forEach(course => {
            addMaterialToTable(course);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

// Function to remove a row from the table
// Function to remove a row from the table and delete it from the server
async function removeRow(button) {
    const row = button.parentNode.parentNode;
    const id = row.dataset.id; // تأكد من أن لديك `data-id` في كل صف

    try {
        const response = await fetch(`http://localhost:3000/api/courses/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            row.parentNode.removeChild(row);
        } else {
            alert('Failed to delete item');
        }
    } catch (error) {
        alert('Error deleting item');
    }
}

// Function to add a task to the to-do list
async function addTodo() {
    const taskInput = document.getElementById('todo-task');
    const taskValue = taskInput.value.trim();

    if (taskValue === '') {
        alert('Please enter a task.');
        return;
    }

    const newTodo = { task: taskValue };

    try {
        const response = await fetch('http://localhost:3000/api/todos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newTodo)
        });

        if (response.ok) {
            const savedTodo = await response.json();
            addTodoToList(savedTodo);
            taskInput.value = '';
        } else {
            alert('Failed to add task');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while adding the task');
    }
}

function addTodoToList(todo) {
    const listItem = document.createElement('li');
    listItem.dataset.id = todo._id;
    listItem.textContent = todo.task;

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.className = 'btn';
    deleteButton.style.backgroundColor = '#FF6347';
    deleteButton.style.color = '#FFF';
    deleteButton.style.marginLeft = '10px';
    deleteButton.onclick = function () {
        removeTodoItem(listItem, todo._id);
    };

    listItem.appendChild(deleteButton);
    const todoList = document.getElementById('todo-list');
    todoList.appendChild(listItem);
}

// Function to fetch and display todos from the server
async function fetchTodos() {
    try {
        const response = await fetch('http://localhost:3000/api/todos');
        const todos = await response.json();

        todos.forEach(todo => {
            addTodoToList(todo);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

// Function to remove a todo item from the list
async function removeTodoItem(listItem, todoId) {
    try {
        const response = await fetch(`http://localhost:3000/api/todos/${todoId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            listItem.remove();
        } else {
            alert('Failed to remove task');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while removing the task');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    fetchCourses();
    fetchTodos();
});
