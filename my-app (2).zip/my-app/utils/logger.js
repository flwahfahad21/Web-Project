const winston = require('winston');

// إنشاء مستوى التسجيل
const logLevel = 'info'; // يمكنك تغيير هذا إلى 'debug' أو أي مستوى آخر حسب الحاجة

// إعداد logger باستخدام winston
const logger = winston.createLogger({
  level: logLevel,
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(), // لطباعة الرسائل على الكونسول
    new winston.transports.File({ filename: 'logs/app.log' }) // لتخزين الرسائل في ملف
  ],
  exceptionHandlers: [
    new winston.transports.File({ filename: 'logs/exceptions.log' }) // لتخزين الاستثناءات في ملف منفصل
  ],
});

// التعامل مع الأخطاء الغير متوقعة
logger.exceptions.handle(
  new winston.transports.File({ filename: 'logs/exceptions.log' })
);

module.exports = logger;
