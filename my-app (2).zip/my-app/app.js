const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path'); // إضافة هذا السطر
const authRoutes = require('./routes/authRoutes');
const courseRoutes = require('./routes/courseRoutes');
const todoRoutes = require('./routes/todoRoutes');
const { PORT, MONGO_URI } = require('./config/serverConfig');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/todos', todoRoutes);

// Serve the frontend application
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Database connection
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
