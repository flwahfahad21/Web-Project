function addCourse() {
    const courseName = document.getElementById('course-name').value;
    const section = document.getElementById('section').value;
    const startTime = document.getElementById('start-time').value;
    const endTime = document.getElementById('end-time').value;
    const days = Array.from(document.querySelectorAll('input[name="days"]:checked')).map(checkbox => checkbox.value);

    if (!courseName || !section || !startTime || !endTime || days.length === 0) {
        alert('Please fill in all the required fields.');
        return;
    }

    const scheduleTable = document.getElementById('schedule-table');
    scheduleTable.style.display = 'table';

    const scheduleBody = document.getElementById('schedule-body');
    const newRow = document.createElement('tr');
    const timeCell = document.createElement('td');
    timeCell.textContent = `${startTime} - ${endTime}`;
    newRow.appendChild(timeCell);

    for (let i = 0; i < 7; i++) {
        const dayCell = document.createElement('td');
        if (days.includes(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][i])) {
            dayCell.textContent = `${courseName} (${section})`;
            dayCell.classList.add('course-cell');
        }
        newRow.appendChild(dayCell);
    }

    scheduleBody.appendChild(newRow);

    document.getElementById('course-name').value = '';
    document.getElementById('section').value = '';
    document.getElementById('start-time').value = '';
    document.getElementById('end-time').value = '';
    document.querySelectorAll('input[name="days"]').forEach(checkbox => checkbox.checked = false);
}

function addTodo() {
    const task = document.getElementById('todo-task').value;

    if (!task) {
        alert('Please enter a task.');
        return;
    }

    const todoList = document.getElementById('todo-list');
    const newItem = document.createElement('li');
    newItem.textContent = task;
    todoList.appendChild(newItem);

    document.getElementById('todo-task').value = '';
}
